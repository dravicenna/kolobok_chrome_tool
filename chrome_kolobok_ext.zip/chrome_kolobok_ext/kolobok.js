
// 2021 Created by dr Avicenna
// For Future Readers. Im not a JS programmer, so dont kill me for this code.

function calc(e) {
    // Calculate speed and stealth
    if (e != "") {
        const t = e.length;
        const n = e.length / 2;
        const l = [e.slice(0, 2), e.slice(t - 2, t)];
        const r = [e.slice(n - 2, n), e.slice(n, n + 2)];

        var speed = Math.abs(parseInt(l[0], 16) - parseInt(l[1], 16));
        var stealth = ((255 - Math.abs(parseInt(r[0], 16) - parseInt(r[1], 16))) / 255).toFixed(2);
        console.log(stealth)
        console.log(speed)
        }
    else {
        stealth = ''
        speed = ''
    }
    return [stealth, speed.toString()]
} 

async function start(){
    var stealth_speed = ["", ""]
    // var cards = document.getElementsByClassName("title-link ng-star-inserted")
    var cards = document.getElementsByClassName("title-link")
    for (var i = 0, l = cards.length; i < l; i++) {
        try {
            var k_id = cards[i].href.split('/').pop()
        }
        catch(e) {
            console.log(e)
            k_id = ""
        }
        if (k_id != "") {
            var koloGenome = await callKolobok(k_id)
            var stealth_speed = calc(koloGenome)
        }
        if (stealth_speed[0] != "") {
            // Set Stealth color
            if (stealth_speed[0] >= 0 && stealth_speed[0] < 0.3) {
                stealth_speed[0] = stealth_speed[0].fontcolor("red")
            }
            if (stealth_speed[0] >= 0.3 && stealth_speed[0] < 0.65) {
                stealth_speed[0] = stealth_speed[0].fontcolor("orange")
            }
            if (stealth_speed[0] >= 0.65 && stealth_speed[0] <= 1) {
                stealth_speed[0] = stealth_speed[0].fontcolor("green")
            }
            // Set Speed color
            if (stealth_speed[1] >= 0 && stealth_speed[1] < 85) {
                stealth_speed[1] = stealth_speed[1].fontcolor("red")
            }
            if (stealth_speed[1] >= 85 && stealth_speed[1] < 170) {
                stealth_speed[1] = stealth_speed[1].fontcolor("orange")
            }
            if (stealth_speed[1] >= 170 && stealth_speed[1] <= 255) {
                stealth_speed[1] = stealth_speed[1].fontcolor("green")
            }
            try {
                var string_to_write = "<p> ST: " + stealth_speed[0] + " SP: "+ stealth_speed[1] + "</p>"
                cards[i].insertAdjacentHTML('beforeend',  string_to_write)
            }
            catch (e) {
                console.log(e)
            }
        
        }
        await sleep(200)
    }
}
async function callKolobok(idkolobok) {
    // var url = 'https://wax.simplemarket.io/api/v1/item/100000007068519';
    var url = 'https://wax.simplemarket.io/api/v1/item/'+idkolobok;
    console.log(url)
    var param = {
        method: "post"
    };

    return fetch(url, param)
        .then(resp => {
            if (resp.status === 200) {
                return resp.json()
            } else {
                console.log("Status: " + resp.status)
                return Promise.reject("server")
            }
        })
        .then(dataJson => {
            var kolodata = JSON.parse(dataJson.idata);
            var genome = kolodata.genome;
            console.log(kolodata)
            console.log(genome)
            return genome
        })
        .catch(err => {
            if (err === "server") return console.log(err)
        })
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

start();